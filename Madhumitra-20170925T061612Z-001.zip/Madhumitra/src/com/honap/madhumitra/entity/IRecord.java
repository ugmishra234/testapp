package com.honap.madhumitra.entity;

import java.util.Date;

/**
 * Author: Chetan S.
 */
public interface IRecord {
    RecordSummary getRecordSummary();
    Date getRecordDateTime();
}
