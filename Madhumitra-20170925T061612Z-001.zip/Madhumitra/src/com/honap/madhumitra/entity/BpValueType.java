package com.honap.madhumitra.entity;

/**
 * Author: Chetan S.
 */
public class BpValueType {
    public final static String SYSTOLIC = "systolic";
    public final static String DIASTOLIC = "diastolic";
}
